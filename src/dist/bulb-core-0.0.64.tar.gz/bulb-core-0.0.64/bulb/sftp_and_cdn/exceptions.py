class BULBStaticfilesError(Exception):
    pass


class BULBHostSSHKeyError(Exception):
    pass