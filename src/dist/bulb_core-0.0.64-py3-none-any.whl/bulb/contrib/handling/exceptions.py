class BULBAdminError(Exception):
    pass
