from bulb.db.base import gdbh
from bulb.db.Q_filter import Q, Qstr