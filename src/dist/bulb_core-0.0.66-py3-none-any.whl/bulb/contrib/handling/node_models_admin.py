WebsiteSettings_preview_fields = False

WebsiteSettings_fields_infos = {"maintenance": {"type": "checkbox",
                                                "label": "Maintenance"},

                                "logo": {"type": "file",
                                         "format": "image",
                                         "label": "Logo"},

                                "name": {"type": "text",
                                         "label": "Name"}
                                }
